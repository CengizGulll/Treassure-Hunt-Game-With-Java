/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package treasure.hunt;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;
/**
 *
 * @author adaozcelik
 */


public class TreasureHunt {

    DoubleLinkedList<Room> rooms;
    Player player;
    DoubleLinkedList<Integer> visitedRooms;

    public TreasureHunt() {
        rooms = new DoubleLinkedList<>();
        CreateRooms();
        Random rnd = new Random();
        int room = rnd.nextInt(10) + 1;
        player = new Player(room);
        visitedRooms = new DoubleLinkedList<>();
        visitedRooms.insertLast(room);
    }

    private void CreateRooms() {

        Room room1 = new Room(1);
        room1.doors.insertLast(2);
        room1.doors.insertLast(3);
        rooms.insertLast(room1);

        Room room2 = new Room(2);
        room2.doors.insertLast(1);
        room2.doors.insertLast(4);
        rooms.insertLast(room2);

        Room room3 = new Room(3);
        room3.doors.insertLast(1);
        room3.doors.insertLast(4);
        rooms.insertLast(room3);

        Room room4 = new Room(4);
        room4.doors.insertLast(2);
        room4.doors.insertLast(3);
        room4.doors.insertLast(5);
        rooms.insertLast(room4);

        Room room5 = new Room(5);
        room5.doors.insertLast(4);
        room5.doors.insertLast(6);
        rooms.insertLast(room5);

        Room room6 = new Room(6);
        room6.doors.insertLast(5);
        room6.doors.insertLast(7);
        rooms.insertLast(room6);

        Room room7 = new Room(7);
        room7.doors.insertLast(6);
        room7.doors.insertLast(8);
        rooms.insertLast(room7);

        Room room8 = new Room(8);
        room8.doors.insertLast(7);
        room8.doors.insertLast(9);
        rooms.insertLast(room8);

        Room room9 = new Room(9);
        room9.doors.insertLast(8);
        room9.doors.insertLast(10);
        rooms.insertLast(room9);

        Room room10 = new Room(10);
        room10.doors.insertLast(9);
        rooms.insertLast(room10);
    }

    public void playGame() {
        Scanner scanner = new Scanner(System.in);
        Random rndm = new Random();

        while (true) {
            Room currentRoom = getRoomById(player.currentRoom);
            System.out.println(currentRoom);

            System.out.print("select a door to move to: ");
            int newRoomId = -1;

            while (true) {
                try {
                    newRoomId = scanner.nextInt();
                    break;
                } catch (InputMismatchException e) {
                    System.out.println("you entered a wrong input (door number) ! Please enter a valid door number.");
                    scanner.next();
                }
            }

            if (currentRoom.doors.toString().contains(String.valueOf(newRoomId))) {
                player.move(newRoomId);
                Room newRoom = getRoomById(newRoomId);

                if (newRoom.hasTrap) {
                    System.out.println("You have encountered a trap!");
                    if (!player.overcomeTrap()) {
                        System.out.println("You failed to overcome the trap, therefore you are moving back to previous room.");
                        player.moveToPreviousRoom();
                        newRoom.trapEncountered = true;
                    }
                }

                if (!newRoom.hasTrap && !newRoom.treasureCollected) {
                    if (rndm.nextBoolean()) {
                        String treasure = "Treasure in room " + newRoomId;
                        player.collect(treasure, newRoom);
                    } else {
                        System.out.println("You have encountered a trap!");
                        newRoom.hasTrap = true;
                        if (!player.overcomeTrap()) {
                            System.out.println("You failed to overcome the trap, therefore you are moving back to previous room.");
                            player.moveToPreviousRoom();
                        }
                        newRoom.trapEncountered = true;
                    }
                } else if (newRoom.treasureCollected) {
                    System.out.println("This room had a treasure, but it has already been collected so that you should move to other doors.");
                }

                if (!RoomVisited(newRoomId)) {
                    visitedRooms.insertLast(newRoomId);
                }
                player.Status();

                if (allRoomsVisited()) {
                    System.out.println("You completed the game! You have visited all rooms.");
                    break;
                }
            } else {
                System.out.println("You entered an invalid move option! Choose a valid door.");
            }
        }

        scanner.close();
    }

    private Room getRoomById(int roomId) {
        DoubleNode<Room> current = rooms.first;
        while (current != null) {
            if (current.data.roomId == roomId) {
                return current.data;
            }
            current = current.next;
        }
        return null;
    }

    private boolean RoomVisited(int roomId) {
        DoubleNode<Integer> current = visitedRooms.first;
        while (current != null) {
            if (current.data == roomId) {
                return true;
            }
            current = current.next;
        }
        return false;
    }

    private boolean allRoomsVisited() {
        for (int i = 1; i <= 10; i++) {
            if (!RoomVisited(i)) {
                return false;
            }
        }
        return true;
    }
}
