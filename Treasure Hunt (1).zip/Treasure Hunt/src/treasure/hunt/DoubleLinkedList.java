/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package treasure.hunt;

/**
 *
 * @author adaozcelik
 */
public class DoubleLinkedList <T> {
       DoubleNode <T> first;
    DoubleNode <T> last;

    public DoubleLinkedList() {
        first = null;
        last = null;
    }

    void insertFirst(DoubleNode <T> newNode) { // can be int also. If int create a new node.
        
        if (last == null) 
        {
            last = newNode;
        } else {
            newNode.next = first;
            first.previous = newNode;
        }
        first = newNode;
    }

    void insertAfter(DoubleNode <T> newNode, DoubleNode <T> prev) {
        DoubleNode t2 = prev.next;
        newNode.next = t2;
        newNode.previous = prev;

        t2.previous = newNode;
        prev.next = newNode;
    }

    void insertLast( T data) {
       DoubleNode<T> newNode = new DoubleNode<>(data);
        if (first == null) {
            first = newNode;
        } else {
            last.next = newNode;
            newNode.previous = last;
        }
        last = newNode;
    }

    @Override
    public String toString() {
        String s = "";
        DoubleNode tmp = first;
        while (tmp != null) {
            s += tmp.data + "<->";
            tmp = tmp.next;
        }
        s += "Null";
        return s;
    }

}