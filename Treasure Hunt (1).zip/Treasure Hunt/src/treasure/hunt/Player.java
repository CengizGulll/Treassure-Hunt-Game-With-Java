/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package treasure.hunt;

import java.util.Random;

/**
 *
 * @author adaozcelik
 */
public class Player {

    int currentRoom;
    LinkedListStack<String> steps;
    LinkedListStack<String> treasures;
    LinkedListStack<Integer> roomData;

    public Player(int startRoom) {
        this.currentRoom = startRoom;
        this.steps = new LinkedListStack<>(100);
        this.treasures = new LinkedListStack<>(100);
        this.roomData = new LinkedListStack<>(100);

        steps.push("Started in Room " + startRoom);
        roomData.push(startRoom);
    }

    public void move(int newRoom) {
        steps.push("Moved from Room " + currentRoom + " to Room " + newRoom);
        currentRoom = newRoom;
        roomData.push(currentRoom);
    }

    public void moveToPreviousRoom() {
        if (!roomData.isEmpty()) {
            roomData.pop();
            currentRoom = roomData.pop();
            roomData.push2(currentRoom);
        }
    }

    public void collect(String treasure, Room room) {
        if (!room.treasureCollected) {
            treasures.push(treasure);
            steps.push("Collected treasure: " + treasure);
            room.treasureCollected = true;
        } else {
            steps.push("Treasure has already been collected in the Room " + room.roomId);
        }
    }

    public boolean overcomeTrap() {
        Random rand = new Random();
        int diceRoll = rand.nextInt(6) + 1;
        steps.push("you encountered a trap, dice is rolling: " + diceRoll);
        return diceRoll % 2 == 0;
    }

    public void Status() {
        System.out.println("Current Room: " + currentRoom);
        System.out.println("steps: ");
        System.out.println(steps.toString());
        System.out.println("Treasures: ");
        System.out.println(treasures.toString());
    }
}
