/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package treasure.hunt;

/**
 *
 * @author adaozcelik
 */
public class DoubleNode<T> {

    T data;
    DoubleNode next;
    DoubleNode previous;

    public DoubleNode(T data) {
        this.data = data;
        next = null;
        previous = null;
    }

}
