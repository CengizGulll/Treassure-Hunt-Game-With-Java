/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package treasure.hunt;

/**
 *
 * @author adaozcelik
 */


public class Room {
    int roomId;
    DoubleLinkedList<Integer> doors;
    boolean treasureCollected; 
    boolean hasTreasure; 
    boolean hasTrap; 
    boolean trapEncountered;
    
    public Room(int roomId) {
        this.roomId = roomId;
        this.doors = new DoubleLinkedList<>();
        
        this.treasureCollected = false; 
        this.hasTreasure = false;
        this.hasTrap = false;
        this.trapEncountered = false;
    }

    @Override
    public String toString() {
        return "Room " + roomId + " with doors to " + doors.toString();
    }
}
