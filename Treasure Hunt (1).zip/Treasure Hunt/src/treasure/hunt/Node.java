/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package treasure.hunt;

/**
 *
 * @author adaozcelik
 */
public class Node <T> {
      public T data;
    public Node next;

    public Node(T data) {
        this.data = data;
        this.next = null;
    }

    @Override
    public String toString() {
        String s = "";
        s += "Node with data: " + data;
        return s; 
    }

    

}
