/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package treasure.hunt;

/**
 *
 * @author adaozcelik
 */
public class LinkedListStack <T>{
    
    public int N; // size of the stack 
    public Node<T> top; // this is the TOP of the stack

    public LinkedListStack(int N) {
         this.N=N;
        top=null;
   
    }

    public boolean isEmpty() {
        return top == null;
    }

    public int size() {
        return N;
    }

    public void push(T t) {
        Node<T> oldfirst = top;
        top = new Node<T>(t);
        top.next = oldfirst;
        N++;
    }

    public void push2(T t) {
        Node<T> newNode = new Node<T>(t);
        newNode.next = top;
        top = newNode;
        N++;
    }

    public Node<T> top() {
        return top;
    }
    
    

    public T pop() {
        if (isEmpty()) {
            System.out.println("The list is already empty");
            return null;
        }
        T return_value = top.data;
        top = top.next;
        return return_value;
    }
    
    
    
    @Override
    public String toString() {
        String result = "";
        Node<T> current = top;
        while (current != null) {
            result += current.data + " -> ";
            current = current.next;
        }
        result += "null";
        return result;
}

    
}