/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package treasure.hunt;

/**
 *
 * @author adaozcelik
 */
public class ProjectTestClass {

    public static void main(String[] args) {
        TreasureHunt game = new TreasureHunt();
        game.playGame();
    }

}
